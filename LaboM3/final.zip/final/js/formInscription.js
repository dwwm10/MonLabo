$(function () {

    // Initialisation de la méthode
    var validator = $("#inscriptionForm").validate({


        rules: {
            // Le nom de la clé sur le côté gauche concerne l'attribut name
            // d'un champ de saisie. Les règles de validation sont définies
            // sur le côté droit
            nom: {
                required: true,
                minlength: 3,
                regex: /^[a-zA-Z ]*$/
            },
            prenom: {
                required: true,
                minlength: 3,
                maxlength: 50,
                regex: /^[a-zA-Z ]*$/


            },

            password: {
                required: true,
                minlength: 5,
                regex: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/
            },
            email: {
                required: true,
                // Specifié que l'email doit être validé
                // par la règle "e-mail" intégrée
                email: true,
                regex: /^[a-z0-9\-_.]+@[a-z0-9\-_.]+\.[a-z]{2,3}$/i
                // le mot commence par une lettre ou un 
                // chiffre ceci une fois ou plus, ensuite on a un arobase, puis encore des lettres ou 
                // chiffres une fois ou plus. Ensuite, on trouve un point et enfin, on a deux ou
                //  trois caractères de suite.
            },
            pays: {
                required: true,
            },

        },
        messages: {
            nom: {
                required: "Vous devez indiquer votre nom.",
                minlength: "Entrer un nom a plus de 3 caractères.",
                regex: "Veuillez entrer que des lettres",
            },
            prenom: {
                required: "Vous devez indiquer votre prenom.",
                minlength: "Entrer un prenom à plus de 3 caractères.",
                maxlength: "pas plus de 50",
                regex: "Veuillez entrer que des lettres",

            },
            password: {
                required: "Vous devez indiquer un mot de passe.",
                minlength: "Veuillez entrer plus de 5 caractères.",
                regex: 'Le mot de passe doit contenir : <br>' +
                    '• Au moins une lettre minuscule <br>' +
                    '• Au moins une lettre majuscule <br>' +
                    '• Au moins un chiffre <br>' +
                    '• Au moins huit caractères.'
            },
            email: {
                required: "Vous devez indiquer votre adresse email.",
                email: "Veuillez entrer un email valide.",
                regex: "Veuillez entrer un email valide."

            },
            pays: {
                required: "Veuillez selectionner un pays."
            },

        },
        // Assurez-vous que le formulaire est soumis à la destination définie
        // dans l'attribut "action" du formulaire lorsqu'il est valide
        // submitHandler: function (form) {
        //     form.submit();
        // }
    });
    // reset le formulaire
    $("#btnAccueil").click(function () {
        validator.resetForm();
    });

    $('#envoiI').click(function () {

        event.preventDefault(); // bloque son action par defaut

        var email = $('#mail').val();
        console.log(email);
        var password = $('#mdp').val();
        var nom = $('#nom').val();
        var prenom = $('#prenom').val();
        var pays = $('#pays').val();

        // si champs formulaire different de vide
        if (email != "" && password != "" && nom != "" && prenom != "" && pays != "") { // si c'est ok

            $('.valid').css('display', 'block');
            $(".laSidebar").show();
            $(".leCaroussel").show();
            $("footer").show();
            $("#searchMobile").addClass("d-inline");
            $("#searchMobile").removeClass("d-none");
            $("#barSearch").addClass("d-sm-inline");
            $("#iconBar").show();
            $(".logout").show();
            $(".login").hide();
            $(".signUp").hide();
            $(".nomUtilisateur").text(prenom);
            $(".dc").hide();
            $(".pageInscription").hide();
            console.log("valider");
        }
        else {
            $('.errorc').css('display', 'block'); // sinon montre msg erreur
            console.log("erreur");
        }
    });

// ajout methode expression reguliere pour controle validation
    $.validator.addMethod(
        "regex",
        function (value, element, regexp) {
            if (regexp.constructor != RegExp)
                regexp = new RegExp(regexp); //si reconnaissance regex Ok          
            else if (regexp.global) 
                regexp.lastIndex = 0;
            return this.optional(element) || regexp.test(value);
        }, "erreur expression reguliere"
    );
});