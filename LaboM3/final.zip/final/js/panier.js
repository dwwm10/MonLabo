jQuery(document).ready(function ($) {

    var nbrpdt = 0;
    var prixU = 0;
    var totalPrix = 0;
    var numP = 0;

    // Fait apparaitre le panier au passage souris
    $( ".panier" ).mouseover(function() {
        $(".mini-panier").show();
    });
    $( ".panier" ).mouseout(function() {
        $(".mini-panier").hide();
    });

    // Ajoute au panier
    // $(".btnAjouter").click(function(){
    $('#listeAlbums').on('click', '.btnAjouter', function(e){

        $(".messPanierVide").hide(); // Retire le message "panier vide"

        // Affiche le nombre de produit ajouter au panier
        $("span.nb-pdt").show();
        nbrpdt = nbrpdt + 1;
        $("span.nb-pdt").text(nbrpdt);

        // Prix Total
        prixU = parseFloat($(this).siblings(".prixAlbum").text());
        totalPrix = (totalPrix + prixU);

        numP = numP + 1;


        // Ajoute le produit dans le panier PopUp
        $("ul.list").append(`<li class="titreETprix" id="` + numP + `"><div>
        <img src="` + $(this).parent().siblings(".card-img-top").attr('src') + `" width="25%"> 
        <p id="titre">` + $(this).siblings(".card-title").text() + `</p>
        <p id="prix">` +  $(this).siblings(".prixAlbum").text() + `</p>
        </div></li>`);
        $("#messMax").text(nbrpdt + " produits ajoutés");

        

        // Ajoute le produit dans la Page Panier
        $("tbody.panierPage").append(`
        <tr class="lignePanier">
        <td class="cacher">` + numP + `</td>
        <td class="text-center"><img src="`+ $(this).parent().siblings(".card-img-top").attr('src') + `"class="img_panier"></td>
        <td class="text-center">` + $(this).siblings(".card-title").text() + `</td>
        <td class="text-center">` + $(this).siblings("p").children("#serie").text() + `</td>
        <td class="text-center">` + $(this).siblings("p").children("#auteur").text() + `</td>
        <td class="text-center" id="prix" >`+  $(this).siblings(".prixAlbum").text() + `</td>
        <td class="text-center"><button type="button" class="btnsupp">
                        <i class="fa fa-trash"></i>
                    </button></td>
        </tr> `); 


        $(".total").text("TOTAL : " + totalPrix.toFixed(2) + "€"); // affiche le prix total avec une limite de 2 chiffre après la virgule
        $(".total").show();
        $("#totalTTC").text(totalPrix.toFixed(2) + "€");
    });

     // Affiche le panier et fait disparaitre page accueil

     $(".voirPanier").click(function(){
        if(nbrpdt>0){
            $(".col-lg-3").hide();
            $(".col-lg-9").hide();
            $(".pagePanier").show();
            $("footer").hide();
        } else {
            $(".col-lg-3").hide();
            $(".col-lg-9").hide();
            $(".messPanierVidePage").show();
        }
    })

    $(".pagePrecPagePanier").click(function(){
        $(".col-lg-3").show();
        $(".col-lg-9").show();
        $(".pagePanier").hide();
        $(".messPanierVidePage").hide();
    })


    // Affiche page d'accueil et fait disparaitre panier
    $(".pagePrec").click(function(){
        $(".col-lg-3").show();
        $(".col-lg-9").show();
        $(".pagePanier").hide();
        $(".messPanierVidePage").hide();
    })


    // Valider le panier
    $(".validePanier").click(function(){
        var connecterOk = $(".nomUtilisateur").text();
        if(connecterOk == ""){
            console.log("aucun boug connecter");
            $(".laSidebar").hide();
            $(".leCaroussel").hide();
            $("footer").hide();
            $("#searchMobile").removeClass("d-inline");
            $("#searchMobile").addClass("d-none");
            $("#barSearch").removeClass("d-sm-inline");
            $("#iconBar").hide();
            $(".pageConnexion").show();
            $(".pagePanier").hide();
            $(".messPanierValider").hide();
            $(".messPanierVidePage").hide();
        } else {
            $(".pagePanier").hide();
            $("#panierValider").text("Nous allons procéder au paiement de votre commande.");
            $(".messPanierValider").show();
            $("footer").hide();
            
            $("tr.lignePanier").remove(); // supprime les lignes du tableau
            $(".titreETprix").remove(); // supprime les produits du panier permanent
            $("span.nb-pdt").text(""); // met a zero le nombre de produits actuelle
            $("span.nb-pdt").hide(); // cache la bulle jaune indiquant le nombre de produits
            nbrpdt = 0; // passe la variable nombre produits a 0
            $(".total").text(""); // efface le message indiquant le total dans le panier parmanent
            $(".total").hide();  // et on le cache
            $("#totalTTC").text("0€"); // on met le total ttc a 0 dans la page panier
            $("#messMax").text(""); // efface le message "X nombre de produits ajouté"
            $(".messPanierVide").show(); // affiche le message "votre panier est vide" et le bouton précédent
            totalPrix = 0;
            numP = 0;
            numBD = 0;
        }
    })

    // Retire un produit de la liste, enelve un poduit au panier, re calcule le prix totale
    $('table').on('click', '.btnsupp', function(e){

        var numBD = ($(this).closest('tr').children('.cacher').text());
        var liste = "li#" + numBD;
        $(liste).remove();


        $(this).closest('tr').remove();
        prixU = parseFloat($(this).closest('tr').children("#prix").text());
        totalPrix = (totalPrix - prixU);
        $(".total").text("TOTAL : " + totalPrix.toFixed(2) + "€"); // affiche le prix total avec une limite de 2 chiffre après la virgule
        $("#totalTTC").text(totalPrix.toFixed(2) + "€");
        nbrpdt = nbrpdt - 1;
        $("span.nb-pdt").text(nbrpdt);
        $("#messMax").text(nbrpdt + " produits ajoutés");
        if(nbrpdt==0){
            $("span.nb-pdt").hide();
            $("span.nb-pdt").text("");
            $("#messMax").text("");
            $(".messPanierVide").show();
            $(".pagePanier").hide();
            $(".messPanierVidePage").show();
            $(".total").hide(); 
            numP = 0;
            $(".messPanierValider").hide();
        }
        liste = "";
        
     });


     // Vide "les panier", reset le nbr de produit, reset les prix a 0e, affiche message panier vide
     $(".viderPanier").click(function(){ 
        $("tr.lignePanier").remove(); // supprime les lignes du tableau
        $(".titreETprix").remove(); // supprime les produits du panier permanent
        $("span.nb-pdt").text(""); // met a zero le nombre de produits actuelle
        $("span.nb-pdt").hide(); // cache la bulle jaune indiquant le nombre de produits
        nbrpdt = 0; // passe la variable nombre produits a 0
        $(".total").text(""); // efface le message indiquant le total dans le panier parmanent
        $(".total").hide();  // et on le cache
        $("#totalTTC").text("0€"); // on met le total ttc a 0 dans la page panier
        $("#messMax").text(""); // efface le message "X nombre de produits ajouté"
        $(".messPanierVide").show(); // affiche le message "votre panier est vide" et le bouton précédent
        $(".pagePanier").hide(); // 
        $(".messPanierVidePage").show();
        $(".messPanierValider").hide();
        totalPrix = 0;
        numP = 0;
        numBD = 0;
    });

});