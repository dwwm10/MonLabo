$(function () {


    var validator = $("#connexionForm").validate({

        rules: {

            email: {
                required: true,
                email: true,
                regex: /^[a-z0-9\-_.]+@[a-z0-9\-_.]+\.[a-z]{2,3}$/i
            },
            passwordc: {
                required: true,
            },
        },
        messages: {

            passwordc: {
                required: "Vous devez indiquer un mot de passe.",
            },
            email: {
                required: "Vous devez indiquer votre adresse email.",
                email: "Veuillez entrer un email valide.",
                regex: "Veuillez entrer un email valide."

            },

        },
        // test personnaliser emplacement message erreur 

        // errorElement:'p',
        // errorLabelContainer: '.errorc',

        // test conserver structure pour emplacement message erreur

        // errorPlacement:function(error,element) {
        // var placement = $(element).data("error"); 
        //associe les données a un element du dom sans l'affecté
        //     if(placement){
        //         $(placement).append(error)
        //     } else {
        //         error.insertAfter(element);
        //     }
        // }


        // Make sure the form is submitted to the destination defined
        // in the "action" attribute of the form when valid
        // submitHandler: function (form) {
        //     form.submit();
        // }
    });
    // reset le formulaire
    $("#btnAccueil").click(function () {
        validator.resetForm();
    });

    // contrôle avant envoi connexion
    $('#envoic').click(function () {

        event.preventDefault(); // bloque son action par defaut

        var ValidEmail = $('#mailc').val() === 'toto@polenumerique.re'; // Mail valide
        var ValidPassword = $('#mdpc').val() === 'Afpar2020'; // Mot de passe valide
        var prenom = 'toto';

        if (ValidEmail === true && ValidPassword === true) { // si c'est ok
            $('.valid').css('display', 'block');
            $(".laSidebar").show();
            $(".leCaroussel").show();
            $("footer").show();
            $("#searchMobile").addClass("d-inline");
            $("#searchMobile").removeClass("d-none");
            $("#barSearch").addClass("d-sm-inline");
            $("#iconBar").show();
            $(".logout").show();
            $(".login").hide();
            $(".signUp").hide();
            $(".dc").hide();
            $(".pageConnexion").hide(); // go to home.html
            $(".nomUtilisateur").text(prenom);
   
        }
        else {
            $('.errorc').css('display', 'block'); // sinon montre msg erreur
            $("#mdpc").val("");
        }
    });

    // ajout methode regex pour controle validation
    $.validator.addMethod(
        "regex",
        function (value, element, regexp) {
            if (regexp.constructor != RegExp)
                regexp = new RegExp(regexp);
            else if (regexp.global)
                regexp.lastIndex = 0;
            return this.optional(element) || regexp.test(value);
        }, "erreur expression reguliere"
    );

    // test fermeture modal dans modal
    // $('.envoiMdpOubli').click(function (e) {
    //     $('#modalMdpLost')
    //         .hide();
    // });
    // $('.envoiMdpOubli').click(function (e) {
    //     e.preventDefault();
    //     $('#confirmationMdpOubli')
    //         .show();


    // });


});