
//MAIN >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  var nbFind = 0;
//Effectue la recherche à chaque fois qu'un caractère est saisi...
$("#rechercher").on("keyup",function(){

  $("#listeAlbums").empty();

  console.clear();
 
  var search = $("#rechercher").val().toLowerCase();

  

  if(search.length >= 2 ){
    
 
    //Pour chaques elements de l'objet Map,...
    for (const [key,value] of albums.entries()) {
  
      //...si le  titre de l'objet correspond à la recherche alors on affiche l'objet.
      if(value.titre.toLowerCase().includes(search)){
        nbFind++;
        /*/TEST -----------------------------
          console.log(nbFind);
          console.log(value.titre);
          console.log(value);
          console.log(series);
          console.log(auteurs);

        //FIN TEST ---------------------------*/

        var titreAlbum = value.titre;//ok
        var prixAlbum = value.prix; //ok
        //GET DATA SERIES--------------------------------------
        var _idSerie = value.idSerie;//ok
        var mySeries = new Map(series);//ok
        var nomSerie = mySeries.get(_idSerie).nom; //ok
        //GET DATA AUTEURS---------------------------------------
        var _idAuteur = value.idAuteur;//ok
        var myAuteurs = new Map(auteurs);//ok
        var nomAuteur = myAuteurs.get(_idAuteur).nom; //ok
        //PARAM URL IMG BD------------------------------------
        var nomFichier = filtrerNomFichier(nomSerie + "-" + value.numero + "-" + titreAlbum);
        var urlImgBD = "../albums/" + nomFichier + ".jpg";

        console.log("Nom serie : " + nomSerie);
        console.log("Nom Auteur(s) : " + nomAuteur);


        // AFFICHAGE RESULTAT : Modification HTML --------------------------------------------
        
        $("#listeAlbums").show();
       
        $("#listeAlbums").append(`
          <div class="col-md-6 mb-4 mx-auto">
            <div class="card h-100 mx-auto">
              <img class="card-img-top" src="${urlImgBD}" alt="Couverture de l'album">

              <div class="card-body">
                <h5 class="card-title">${titreAlbum}</h5>

                <p>
                  Série : ${nomSerie}
                </p>

                <p>
                  Auteur(s) : ${nomAuteur}
                </p>

                <h5 class="prixAlbum">${prixAlbum} €</h5>
                
                <button type="button" class="btnAjouter btn btn-primary mt-2">
                  <i class="fas fa-cart-plus fa-lg"></i>
                </button>
              </div>

              <div class="card-footer">
                <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
              </div>
            </div>
          </div>
        `);

        //Fin Modification HTML ------------------------------------------*/

      //Et si la requete ne correspond à aucune BD alors msg not found.
      }else{
         
       if(nbFind >0){
          nbFind--;
        }   
        
        
      }
      
    }

    if(nbFind <= 0){
      
      $("#listeAlbums").show();
      
      $("#listeAlbums").append(`
      <div class="col-md-6 mb-4 mx-auto">
        <h4>Aucune BD trouvées</h4>
      </div>
      `);

    
      console.error("Aucune BD trouvées");
    }
    
  }

  function filtrerNomFichier(nomFic)
  {
      // Utilisation d'une expression régulière pour supprimer 
      // les caractères non autorisés dans les noms de fichiers : '!?.":$
      return nomFic = nomFic.replace(/'|!|\?|\.|"|:|\$/g, "");
  }

});

