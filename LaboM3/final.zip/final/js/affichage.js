jQuery(document).ready(function ($) {

    // Fait apparaitre le compte utilisateur au passage souris
    $(".userbdking").mouseover(function () {
        $(".mini-userbdking").show();
    });

    // Fait disparaitre le compte utilisateur lorsque la souris quitte
    $(".userbdking").mouseout(function () {
        $(".mini-userbdking").hide();
    });


    // Affiche PAGE CONNEXION(bouton identifier)/Cache PAGE ACCUEIL
    $(".seConnecter").click(function () {
        $(".laSidebar").hide();
        $(".leCaroussel").hide();
        $("footer").hide();
        $("#searchMobile").removeClass("d-inline");
        $("#searchMobile").addClass("d-none");
        $("#barSearch").removeClass("d-sm-inline");
        $("#iconBar").hide();
        $(".pageConnexion").show();

        $(".pagePanier").hide();
        $(".messPanierValider").hide();
        $(".messPanierVidePage").hide();
    });

    // Affiche PAGE INSCRIPTION (bouton s'incrire)/Cache PAGE ACCUEIL
    $(".inscrire").click(function () {
        $(".laSidebar").hide();
        $(".leCaroussel").hide();
        $("footer").hide();
        $("#searchMobile").removeClass("d-inline");
        $("#searchMobile").addClass("d-none");
        $("#barSearch").removeClass("d-sm-inline");
        $("#iconBar").hide();
        $(".pageInscription").show();

        $(".pagePanier").hide();
        $(".messPanierValider").hide();
        $(".messPanierVidePage").hide();
    });

    // Affiche PAGE ACCEUIL(logo) / Cache PAGE CONNEXION
    $("#btnAccueil").click(function () {
        $(".laSidebar").show();
        $(".leCaroussel").show();
        $("footer").show();
        $("#searchMobile").addClass("d-inline");
        $("#searchMobile").removeClass("d-none");
        $("#barSearch").addClass("d-sm-inline");
        $(".errorc").hide();
        $("#iconBar").show();
        $(".pageConnexion").hide();
    });

    // AFFICHE PAGE ACCEUIL(logo)/ Cache PAGE INSCRIPTION
    $("#btnAccueil").click(function () {
        $(".laSidebar").show();
        $(".leCaroussel").show();
        $("footer").show();
        $("#searchMobile").addClass("d-inline");
        $("#searchMobile").removeClass("d-none");
        $("#barSearch").addClass("d-sm-inline");
        $("#iconBar").show();
        $(".pageInscription").hide();

        $(".pagePanier").hide();
        $(".messPanierValider").hide();
        $(".messPanierVidePage").hide();


    });
    // AFFICHE PAGE INSCRIPTION(bouton)/ Cache PAGE CONNEXION
    $("#newInscription").click(function () {
        $(".pageInscription").show();
        $(".pageConnexion").hide();
    });

    //  Se deconnecter / BACK page acceuil 
    $(".logout").click(function () {
        document.location.href = "index.html"; // go to home.html
    });

});