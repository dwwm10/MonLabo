$(document).ready(function ()
{
    // programme principal
    const srcAlbum = "albums/"; // emplacement des images des albums en grand

    // tri par titres
    const tabAlbumsParTitresAb = [];
    const tabAlbumsParTitresCd = [];
    const tabAlbumsParTitresEf = [];
    const tabAlbumsParTitresGh = [];
    const tabAlbumsParTitresIj = [];
    const tabAlbumsParTitresKl = [];
    const tabAlbumsParTitresMn = [];
    const tabAlbumsParTitresOp = [];
    const tabAlbumsParTitresQr = [];
    const tabAlbumsParTitresSt = [];
    const tabAlbumsParTitresUvw = [];
    const tabAlbumsParTitresXyz = [];
    const tabAlbumsParTitresAutres = [];

    // tri par auteurs
    const tabAlbumsParAuteursAb = [];
    const tabAlbumsParAuteursCd = [];
    const tabAlbumsParAuteursEf = [];
    const tabAlbumsParAuteursGh = [];
    const tabAlbumsParAuteursIj = [];
    const tabAlbumsParAuteursKl = [];
    const tabAlbumsParAuteursMn = [];
    const tabAlbumsParAuteursOp = [];
    const tabAlbumsParAuteursQr = [];
    const tabAlbumsParAuteursSt = [];
    const tabAlbumsParAuteursUvw = [];
    const tabAlbumsParAuteursXyz = [];
    const tabAlbumsParAuteursAutres = [];

    // tri par séries
    const tabAlbumsParSeriesAb = [];
    const tabAlbumsParSeriesCd = [];
    const tabAlbumsParSeriesEf = [];
    const tabAlbumsParSeriesGh = [];
    const tabAlbumsParSeriesIj = [];
    const tabAlbumsParSeriesKl = [];
    const tabAlbumsParSeriesMn = [];
    const tabAlbumsParSeriesOp = [];
    const tabAlbumsParSeriesQr = [];
    const tabAlbumsParSeriesSt = [];
    const tabAlbumsParSeriesUvw = [];
    const tabAlbumsParSeriesXyz = [];
    const tabAlbumsParSeriesAutres = [];

    // filtres Regex pour le rangement par groupes de lettres
    const filtreAb = /[AÀB]/;
    const filtreCd = /[CD]/;
    const filtreEf = /[EÉÈÊF]/;
    const filtreGh = /[GH]/;
    const filtreIj = /[IÎJ]/;
    const filtreKl = /[KL]/;
    const filtreMn = /[MN]/;
    const filtreOp = /[OP]/;
    const filtreQr = /[QR]/;
    const filtreSt = /[ST]/;
    const filtreUvw = /[U-W]/;
    const filtreXyz = /[X-Z]/;

    $("#listeAlbums").hide();
    $("#filtreLettres").hide();

    rangerAlbumsParTitresParLettres();
    rangerAlbumsParAuteursParLettres();
    rangerAlbumsParSeriesParLettres();

    trierTousLesTab();

    deployerEcouteursEvenements();

    // range tous les albums par titres
    function rangerAlbumsParTitresParLettres()
    {
        for (const idAlbum of albums.keys())
        {
            const album = albums.get(idAlbum);

            const premiereLettreTitre = filtrerArticlesDefinis(album.titre);

            // range l'album dans le bon tableau selon son titre
            switch (true)
            {
                case (filtreAb.test(premiereLettreTitre)):
                    tabAlbumsParTitresAb.push(album);
                    break;

                case (filtreCd.test(premiereLettreTitre)):
                    tabAlbumsParTitresCd.push(album);
                    break;

                case (filtreEf.test(premiereLettreTitre)):
                    tabAlbumsParTitresEf.push(album);
                    break;

                case (filtreGh.test(premiereLettreTitre)):
                    tabAlbumsParTitresGh.push(album);
                    break;

                case (filtreIj.test(premiereLettreTitre)):
                    tabAlbumsParTitresIj.push(album);
                    break;

                case (filtreKl.test(premiereLettreTitre)):
                    tabAlbumsParTitresKl.push(album);
                    break;

                case (filtreMn.test(premiereLettreTitre)):
                    tabAlbumsParTitresMn.push(album);
                    break;

                case (filtreOp.test(premiereLettreTitre)):
                    tabAlbumsParTitresOp.push(album);
                    break;

                case (filtreQr.test(premiereLettreTitre)):
                    tabAlbumsParTitresQr.push(album);
                    break;

                case (filtreSt.test(premiereLettreTitre)):
                    tabAlbumsParTitresSt.push(album);
                    break;

                case (filtreUvw.test(premiereLettreTitre)):
                    tabAlbumsParTitresUvw.push(album);
                    break;

                case (filtreXyz.test(premiereLettreTitre)):
                    tabAlbumsParTitresXyz.push(album);
                    break;
            
                default:
                    tabAlbumsParTitresAutres.push(album);
            }
        }
    }

    // filtre les articles definis (L', Le, La, Les) au début du nom fourni et donne la première lettre du mot juste après
    function filtrerArticlesDefinis(nom)
    {
        let premiereLettre = "";

        // met la première lettre en majuscule pour un filtre plus simple
        nom = (nom.substring(0, 1).toUpperCase() + nom.substring(1));

        if (/^L'/.test(nom))
        {
            premiereLettre = nom.substring(2, 3).toUpperCase();
        }
        else if (/^Le |^La /.test(nom))
        {
            premiereLettre = nom.substring(3, 4).toUpperCase();
        }
        else if (/^Les /.test(nom))
        {
            premiereLettre = nom.substring(4, 5).toUpperCase();
        }
        else
        {
            premiereLettre = nom.substring(0, 1).toUpperCase();
        }

        return premiereLettre;
    }

    // range tous les albums par auteurs
    function rangerAlbumsParAuteursParLettres()
    {
        for (const idAlbum of albums.keys())
        {
            const album = albums.get(idAlbum);

            const auteur = auteurs.get(album.idAuteur);

            album.nomAuteur = auteur.nom;

            const premiereLettreTitre = album.nomAuteur.substring(0 , 1).toUpperCase();

            // range l'album dans le bon tableau selon son auteur
            switch (true)
            {
                case (filtreAb.test(premiereLettreTitre)):
                    tabAlbumsParAuteursAb.push(album);
                    break;

                case (filtreCd.test(premiereLettreTitre)):
                    tabAlbumsParAuteursCd.push(album);
                    break;

                case (filtreEf.test(premiereLettreTitre)):
                    tabAlbumsParAuteursEf.push(album);
                    break;

                case (filtreGh.test(premiereLettreTitre)):
                    tabAlbumsParAuteursGh.push(album);
                    break;

                case (filtreIj.test(premiereLettreTitre)):
                    tabAlbumsParAuteursIj.push(album);
                    break;

                case (filtreKl.test(premiereLettreTitre)):
                    tabAlbumsParAuteursKl.push(album);
                    break;

                case (filtreMn.test(premiereLettreTitre)):
                    tabAlbumsParAuteursMn.push(album);
                    break;

                case (filtreOp.test(premiereLettreTitre)):
                    tabAlbumsParAuteursOp.push(album);
                    break;

                case (filtreQr.test(premiereLettreTitre)):
                    tabAlbumsParAuteursQr.push(album);
                    break;

                case (filtreSt.test(premiereLettreTitre)):
                    tabAlbumsParAuteursSt.push(album);
                    break;

                case (filtreUvw.test(premiereLettreTitre)):
                    tabAlbumsParAuteursUvw.push(album);
                    break;

                case (filtreXyz.test(premiereLettreTitre)):
                    tabAlbumsParAuteursXyz.push(album);
                    break;
            
                default:
                    tabAlbumsParAuteursAutres.push(album);
            }
        }
    }

    // range tous les albums par séries
    function rangerAlbumsParSeriesParLettres()
    {
        for (const idAlbum of albums.keys())
        {
            const album = albums.get(idAlbum);

            const serie = series.get(album.idSerie);

            album.nomSerie = serie.nom;

            const premiereLettreSerie = filtrerArticlesDefinis(album.nomSerie);

            // range l'album dans le bon tableau selon sa série
            switch (true)
            {
                case (filtreAb.test(premiereLettreSerie)):
                    tabAlbumsParSeriesAb.push(album);
                    break;

                case (filtreCd.test(premiereLettreSerie)):
                    tabAlbumsParSeriesCd.push(album);
                    break;

                case (filtreEf.test(premiereLettreSerie)):
                    tabAlbumsParSeriesEf.push(album);
                    break;

                case (filtreGh.test(premiereLettreSerie)):
                    tabAlbumsParSeriesGh.push(album);
                    break;

                case (filtreIj.test(premiereLettreSerie)):
                    tabAlbumsParSeriesIj.push(album);
                    break;

                case (filtreKl.test(premiereLettreSerie)):
                    tabAlbumsParSeriesKl.push(album);
                    break;

                case (filtreMn.test(premiereLettreSerie)):
                    tabAlbumsParSeriesMn.push(album);
                    break;

                case (filtreOp.test(premiereLettreSerie)):
                    tabAlbumsParSeriesOp.push(album);
                    break;

                case (filtreQr.test(premiereLettreSerie)):
                    tabAlbumsParSeriesQr.push(album);
                    break;

                case (filtreSt.test(premiereLettreSerie)):
                    tabAlbumsParSeriesSt.push(album);
                    break;

                case (filtreUvw.test(premiereLettreSerie)):
                    tabAlbumsParSeriesUvw.push(album);
                    break;

                case (filtreXyz.test(premiereLettreSerie)):
                    tabAlbumsParSeriesXyz.push(album);
                    break;
            
                default:
                    tabAlbumsParSeriesAutres.push(album);
            }
        }
    }

    // trie par ordre alphabétique de tous les tableaux contenant les albums
    function trierTousLesTab()
    {
        // tri des tableaux rangés par titres
        trierTabParTitres(tabAlbumsParTitresAb);
        trierTabParTitres(tabAlbumsParTitresCd);
        trierTabParTitres(tabAlbumsParTitresEf);
        trierTabParTitres(tabAlbumsParTitresGh);
        trierTabParTitres(tabAlbumsParTitresIj);
        trierTabParTitres(tabAlbumsParTitresKl);
        trierTabParTitres(tabAlbumsParTitresMn);
        trierTabParTitres(tabAlbumsParTitresOp);
        trierTabParTitres(tabAlbumsParTitresQr);
        trierTabParTitres(tabAlbumsParTitresSt);
        trierTabParTitres(tabAlbumsParTitresUvw);
        trierTabParTitres(tabAlbumsParTitresXyz);
        trierTabParTitres(tabAlbumsParTitresAutres);

        // tri des tableaux rangés par auteurs
        trierTabParAuteurs(tabAlbumsParAuteursAb);
        trierTabParAuteurs(tabAlbumsParAuteursCd);
        trierTabParAuteurs(tabAlbumsParAuteursEf);
        trierTabParAuteurs(tabAlbumsParAuteursGh);
        trierTabParAuteurs(tabAlbumsParAuteursIj);
        trierTabParAuteurs(tabAlbumsParAuteursKl);
        trierTabParAuteurs(tabAlbumsParAuteursMn);
        trierTabParAuteurs(tabAlbumsParAuteursOp);
        trierTabParAuteurs(tabAlbumsParAuteursQr);
        trierTabParAuteurs(tabAlbumsParAuteursSt);
        trierTabParAuteurs(tabAlbumsParAuteursUvw);
        trierTabParAuteurs(tabAlbumsParAuteursXyz);
        trierTabParAuteurs(tabAlbumsParAuteursAutres);
        
        // tri des tableaux rangés par série
        trierTabParSeries(tabAlbumsParSeriesAb);
        trierTabParSeries(tabAlbumsParSeriesCd);
        trierTabParSeries(tabAlbumsParSeriesEf);
        trierTabParSeries(tabAlbumsParSeriesGh);
        trierTabParSeries(tabAlbumsParSeriesIj);
        trierTabParSeries(tabAlbumsParSeriesKl);
        trierTabParSeries(tabAlbumsParSeriesMn);
        trierTabParSeries(tabAlbumsParSeriesOp);
        trierTabParSeries(tabAlbumsParSeriesQr);
        trierTabParSeries(tabAlbumsParSeriesSt);
        trierTabParSeries(tabAlbumsParSeriesUvw);
        trierTabParSeries(tabAlbumsParSeriesXyz);
        trierTabParSeries(tabAlbumsParSeriesAutres);
    }

    // trie par ordre alphabétique un tableau selon son titre
    function trierTabParTitres(tab)
    {
        tab.sort(function (album1, album2)
        {
            const titreAlbum1 = album1.titre;
            const titreAlbum2 = album2.titre;

            return titreAlbum1.localeCompare(titreAlbum2);
        });
    }

    // trie par ordre alphabétique un tableau selon son auteur
    function trierTabParAuteurs(tab)
    {
        tab.sort(function (album1, album2)
        {
            const nomAuteurAlbum1 = album1.nomAuteur;
            const nomAuteurAlbum2 = album2.nomAuteur;

            return nomAuteurAlbum1.localeCompare(nomAuteurAlbum2);
        });
    }

    // trie par ordre alphabétique un tableau selon sa série
    function trierTabParSeries(tab)
    {
        tab.sort(function (album1, album2)
        {
            const nomSerieAlbum1 = album1.nomSerie;
            const nomSerieAlbum2 = album2.nomSerie;

            return nomSerieAlbum1.localeCompare(nomSerieAlbum2);
        });
    }

    // insère la struture HTML pour afficher tous les articles du tableau demandé
    function afficherTabAlbums(tab)
    {
        for (const album of tab)
        {
            const serie = series.get(album.idSerie);
            const auteur = auteurs.get(album.idAuteur);
            
            const nomFic = filtrerNomFichier(serie.nom + "-" + album.numero + "-" + album.titre);
            const lienImageAlbum = srcAlbum + nomFic + ".jpg";


            $("#listeAlbums").append(`
                <div class="col-md-6 mb-4 mx-auto">
                    <div class="card h-100 mx-auto">
                        <img class="card-img-top" src="${lienImageAlbum}" alt="Couverture de l'album">

                        <div class="card-body">
                            <h5 class="card-title">${album.titre}</h5>

                            <p>
                                Série : <span id="serie">${serie.nom}</span>
                            </p>

                            <p>
                                Auteur(s) : <span id="auteur">${auteur.nom}</span>
                            </p>

                            <h5 class="prixAlbum">${album.prix} €</h5>
                            
                            <button type="button" class="btnAjouter btn btn-primary mt-2">
                                <i class="fas fa-cart-plus fa-lg"></i>
                            </button>
                        </div>

                        <div class="card-footer">
                            <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                        </div>
                    </div>
                </div>
            `);
        }
    }

    // filtre le nom fourni pour obtenir un nom de fichier correct
    function filtrerNomFichier(nomFic)
    {
        // Utilisation d'une expression régulière pour supprimer 
        // les caractères non autorisés dans les noms de fichiers : '!?.":$
        return nomFic = nomFic.replace(/'|!|\?|\.|"|:|\$/g, "");
    }

    // deploie tous les écouteurs d'évènements concernant l'affichage de l'accueil et les listes d'albums demandés
    function deployerEcouteursEvenements()
    {
        // bouton Accueil (logo et nom du site "BD KING" en haut à gauche)
        $("#btnAccueil").click(function ()
        {
            $("#listeAlbums").hide();
            $("#filtreLettres").hide();
            $("#btnDescendreBasPage").hide();
            $("#carrousel").show();

            $(".btnClassement").removeClass("active");
            $(".btnFiltreLettres").removeClass("active");

            $("#listeAlbums").text("");

            $('html,body').animate({scrollTop: 0}, 'slow');
        });

        // boutons Classement
        $("#btnParTitres").click(function ()
        {
            $("#carrousel").hide();
            $("#listeAlbums").show();
            $("#filtreLettres").show();
            $("#btnDescendreBasPage").show();

            $(".btnClassement").removeClass("active");
            $(this).addClass("active");

            $(".btnFiltreLettres").removeClass("active");
            $("#btnAb").addClass("active");
    
            $("#listeAlbums").text("");
            afficherTabAlbums(tabAlbumsParTitresAb);
        });

        $("#btnParAuteurs").click(function ()
        {
            $("#carrousel").hide();
            $("#listeAlbums").show();
            $("#filtreLettres").show();
            $("#btnDescendreBasPage").show();

            $(".btnClassement").removeClass("active");
            $(this).addClass("active");

            $(".btnFiltreLettres").removeClass("active");
            $("#btnAb").addClass("active");
    
            $("#listeAlbums").text("");
            afficherTabAlbums(tabAlbumsParAuteursAb);
        });

        $("#btnParSeries").click(function ()
        {
            $("#carrousel").hide();
            $("#listeAlbums").show();
            $("#filtreLettres").show();
            $("#btnDescendreBasPage").show();

            $(".btnClassement").removeClass("active");
            $(this).addClass("active");

            $(".btnFiltreLettres").removeClass("active");
            $("#btnAb").addClass("active");
    
            $("#listeAlbums").text("");
            afficherTabAlbums(tabAlbumsParSeriesAb);
        });

        // boutons Filtre par lettres
        $("#btnAb").click(function ()
        {
            $(".btnFiltreLettres").removeClass("active");
            $(this).addClass("active");
    
            $("#listeAlbums").text("");
            selectionnerAffichage(tabAlbumsParTitresAb, tabAlbumsParAuteursAb, tabAlbumsParSeriesAb);
        });
    
        $("#btnCd").click(function ()
        {
            $(".btnFiltreLettres").removeClass("active");  
            $(this).addClass("active");
    
            $("#listeAlbums").text("");   
            selectionnerAffichage(tabAlbumsParTitresCd, tabAlbumsParAuteursCd, tabAlbumsParSeriesCd);
        });
    
        $("#btnEf").click(function ()
        {
            $(".btnFiltreLettres").removeClass("active");
            $(this).addClass("active");
    
            $("#listeAlbums").text(""); 
            selectionnerAffichage(tabAlbumsParTitresEf, tabAlbumsParAuteursEf, tabAlbumsParSeriesEf);
        });
    
        $("#btnGh").click(function ()
        {
            $(".btnFiltreLettres").removeClass("active");
            $(this).addClass("active");
    
            $("#listeAlbums").text("");
            selectionnerAffichage(tabAlbumsParTitresGh, tabAlbumsParAuteursGh, tabAlbumsParSeriesGh);
        });
    
        $("#btnIj").click(function ()
        {
            $(".btnFiltreLettres").removeClass("active");
            $(this).addClass("active");
    
            $("#listeAlbums").text("");
            selectionnerAffichage(tabAlbumsParTitresIj, tabAlbumsParAuteursIj, tabAlbumsParSeriesIj);
        });
    
        $("#btnKl").click(function ()
        {
            $(".btnFiltreLettres").removeClass("active");
            $(this).addClass("active");
    
            $("#listeAlbums").text("");
            selectionnerAffichage(tabAlbumsParTitresKl, tabAlbumsParAuteursKl, tabAlbumsParSeriesKl);
        });
    
        $("#btnMn").click(function ()
        {
            $(".btnFiltreLettres").removeClass("active");
            $(this).addClass("active");
    
            $("#listeAlbums").text("");
            selectionnerAffichage(tabAlbumsParTitresMn, tabAlbumsParAuteursMn, tabAlbumsParSeriesMn);
        });
    
        $("#btnOp").click(function ()
        {
            $(".btnFiltreLettres").removeClass("active");
            $(this).addClass("active");
    
            $("#listeAlbums").text("");
            selectionnerAffichage(tabAlbumsParTitresOp, tabAlbumsParAuteursOp, tabAlbumsParSeriesOp);
        });
    
        $("#btnQr").click(function ()
        {
            $(".btnFiltreLettres").removeClass("active");
            $(this).addClass("active");
    
            $("#listeAlbums").text("");
            selectionnerAffichage(tabAlbumsParTitresQr, tabAlbumsParAuteursQr, tabAlbumsParSeriesQr);
        });
    
        $("#btnSt").click(function ()
        {
            $(".btnFiltreLettres").removeClass("active");
            $(this).addClass("active");
    
            $("#listeAlbums").text("");
            selectionnerAffichage(tabAlbumsParTitresSt, tabAlbumsParAuteursSt, tabAlbumsParSeriesSt);
        });
    
        $("#btnUvw").click(function ()
        {
            $(".btnFiltreLettres").removeClass("active");
            $(this).addClass("active");
    
            $("#listeAlbums").text("");
            selectionnerAffichage(tabAlbumsParTitresUvw, tabAlbumsParAuteursUvw, tabAlbumsParSeriesUvw);
        });
    
        $("#btnXyz").click(function ()
        {
            $(".btnFiltreLettres").removeClass("active");
            $(this).addClass("active");
    
            $("#listeAlbums").text("");
            selectionnerAffichage(tabAlbumsParTitresXyz, tabAlbumsParAuteursXyz, tabAlbumsParSeriesXyz);
        });
        
        $("#btnAutres").click(function ()
        {
            $(".btnFiltreLettres").removeClass("active");
            $(this).addClass("active");
    
            $("#listeAlbums").text("");
            selectionnerAffichage(tabAlbumsParTitresAutres, tabAlbumsParAuteursAutres, tabAlbumsParSeriesAutres);
        });
    }

    // sélectionne et affiche le bon tableau selon le type de tri choisi (balise bouton active)
    function selectionnerAffichage(tabParTitres, tabParAuteurs, tabParSeries)
    {
        switch (true)
        {
            case $("#btnParTitres").hasClass("active"):
                afficherTabAlbums(tabParTitres);
                break;

           case $("#btnParAuteurs").hasClass("active"):
                afficherTabAlbums(tabParAuteurs);
                break;

           case $("#btnParSeries").hasClass("active"):
                afficherTabAlbums(tabParSeries);
                break;
        }
    }

    // construit un bouton permettant de remonter en haut de page
    (function btnRemonterHautPage()
    {
        $('<div></div>')
            .attr('id','btnRemonterHautPage')
            .hide()
            .css({'z-index':'1000','position':'fixed','bottom':'85px','right':'20px','cursor':'pointer','width':'40px','height':'40px','background':'#111111'})
            .appendTo('body')
            .click(function(){
                $('html,body').animate({scrollTop: 0}, 'slow');
            });

        $('<div></div>')
            .css({'width':'6px','height':'6px','transform':'rotate(-135deg)','border':'solid #ffffff','border-width':'0 3px 3px 0','padding':'6px','margin-top':'16px','margin-left':'12px'})
            .appendTo('#btnRemonterHautPage');

        $(window).scroll(function(){
            if($(window).scrollTop() < 500){
                $('#btnRemonterHautPage').fadeOut();
            }else{
                $('#btnRemonterHautPage').fadeIn();
            }
        });
    })();

    // construit un bouton permettant de descendre en bas de page
    (function btnDescendreBasPage()
    {
        $('<div></div>')
            .attr('id','btnDescendreBasPage')
            .hide()
            .css({'z-index':'1000','position':'fixed','bottom':'25px','right':'20px','cursor':'pointer','width':'40px','height':'40px','background':'#111111'})
            .appendTo('body')
            .click(function(){
                $('html,body').animate({scrollTop: $(document).height()}, 'slow');
            });

        $('<div></div>')
            .css({'width':'6px','height':'6px','transform':'rotate(-135deg)','border':'solid #ffffff','border-width':'3px 0 0 3px','padding':'6px','margin-top':'8px','margin-left':'12px'})
            .appendTo('#btnDescendreBasPage');
    })();
});